import {Component} from 'react'

class Home extends Component{
    render(){
        return(
            <div>
                <h1>hi</h1>
            </div>
        )
    }
}

export default Home